package com.faudio.player

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.InputStream

/** Lets the service talk to the page. */
object Bridge {
    @Volatile
    var web: WebView? = null

    fun js(code: String) {
        val w = web ?: return
        w.post { w.evaluateJavascript(code, null) }
    }
}

class MainActivity : Activity() {

    private val host = "appassets.androidplatform.net"
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    // ---------- permissions ----------
    private fun audioPerm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission(): Boolean =
        checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED

    private fun askPermission() {
        val list = ArrayList<String>()
        list.add(audioPerm())
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Bridge.js("window.onPermission&&window.onPermission(" + hasAudioPermission() + ")")
    }

    // ---------- JS bridge ----------
    inner class JsApi {
        @JavascriptInterface
        fun hasPermission(): Boolean = hasAudioPermission()

        @JavascriptInterface
        fun requestPermission() {
            runOnUiThread { askPermission() }
        }

        @JavascriptInterface
        fun getSongs(minSec: Int): String = MediaUtil.querySongs(applicationContext, minSec)

        @JavascriptInterface
        fun nowPlaying(
            id: Long, albumId: Long, title: String, artist: String,
            playing: Boolean, posMs: Long, durMs: Long
        ) {
            val st = PlayState(id, albumId, title, artist, playing, posMs, durMs)
            runOnUiThread { PlayerService.push(applicationContext, st) }
        }

        @JavascriptInterface
        fun share(id: Long) {
            runOnUiThread {
                try {
                    val uri = MediaUtil.songUri(id)
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "audio/*"
                    i.putExtra(Intent.EXTRA_STREAM, uri)
                    i.clipData = ClipData.newRawUri("", uri)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, null))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun setBars(light: Boolean) {
            runOnUiThread { applyBars(light) }
        }
    }

    @Suppress("DEPRECATION")
    private fun applyBars(light: Boolean) {
        window.statusBarColor = if (light) 0xFFFBFBF7.toInt() else 0xFF8C8C88.toInt()
        window.navigationBarColor = if (light) 0xFFC6C6BE.toInt() else 0xFF2B2B29.toInt()
        var flags = 0
        if (light) {
            if (Build.VERSION.SDK_INT >= 23) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
    }

    // ---------- serving assets / songs / covers to the WebView ----------
    private fun notFound(): WebResourceResponse =
        WebResourceResponse(
            "text/plain", "utf-8", 404, "Not Found", HashMap<String, String>(),
            ByteArrayInputStream(ByteArray(0))
        )

    private fun mimeFor(name: String): String {
        val n = name.lowercase()
        return when {
            n.endsWith(".html") -> "text/html"
            n.endsWith(".js") -> "application/javascript"
            n.endsWith(".css") -> "text/css"
            n.endsWith(".json") -> "application/json"
            n.endsWith(".png") -> "image/png"
            n.endsWith(".jpg") || n.endsWith(".jpeg") -> "image/jpeg"
            n.endsWith(".webp") -> "image/webp"
            n.endsWith(".svg") -> "image/svg+xml"
            else -> "application/octet-stream"
        }
    }

    private fun serveAsset(path: String): WebResourceResponse? {
        val name = if (path == "/" || path.isEmpty()) "index.html" else path.trimStart('/')
        return try {
            val mime = mimeFor(name)
            WebResourceResponse(
                mime, if (mime.startsWith("text/") || mime.contains("javascript")) "utf-8" else null,
                assets.open(name)
            )
        } catch (e: Exception) {
            notFound()
        }
    }

    private class LimitedStream(
        private val fis: FileInputStream,
        private var left: Long,
        private val afd: android.content.res.AssetFileDescriptor
    ) : InputStream() {
        override fun read(): Int {
            if (left <= 0) return -1
            val r = fis.read()
            if (r >= 0) left--
            return r
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val want = if (len.toLong() > left) left.toInt() else len
            val r = fis.read(b, off, want)
            if (r > 0) left -= r.toLong()
            return r
        }

        override fun available(): Int = if (left > Int.MAX_VALUE) Int.MAX_VALUE else left.toInt()

        override fun close() {
            try { fis.close() } catch (e: Exception) { }
            try { afd.close() } catch (e: Exception) { }
        }
    }

    /** Song bytes with HTTP Range support so seeking works. */
    private fun serveSong(id: Long, range: String?): WebResourceResponse? {
        return try {
            val uri = MediaUtil.songUri(id)
            val afd = contentResolver.openAssetFileDescriptor(uri, "r") ?: return notFound()
            var total = afd.length
            if (total < 0) total = afd.parcelFileDescriptor.statSize
            var start = 0L
            var end = total - 1
            var partial = false
            if (range != null && range.startsWith("bytes=")) {
                val p = range.substring(6).split(",")[0].trim().split("-")
                val s = if (p.isNotEmpty()) p[0] else ""
                val e = if (p.size > 1) p[1] else ""
                if (s.isNotEmpty()) {
                    start = s.toLong()
                    if (e.isNotEmpty()) end = minOf(e.toLong(), total - 1)
                } else if (e.isNotEmpty()) {
                    start = maxOf(0L, total - e.toLong())
                }
                partial = true
            }
            if (start > end || start >= total) {
                afd.close()
                return WebResourceResponse(
                    "text/plain", "utf-8", 416, "Range Not Satisfiable",
                    hashMapOf("Content-Range" to "bytes */$total"),
                    ByteArrayInputStream(ByteArray(0))
                )
            }
            val fis = FileInputStream(afd.fileDescriptor)
            fis.channel.position(afd.startOffset + start)
            val len = end - start + 1
            val headers = HashMap<String, String>()
            headers["Accept-Ranges"] = "bytes"
            headers["Content-Length"] = len.toString()
            headers["Access-Control-Allow-Origin"] = "*"
            if (partial) headers["Content-Range"] = "bytes $start-$end/$total"
            val mime = contentResolver.getType(uri) ?: "audio/mpeg"
            WebResourceResponse(
                mime, null,
                if (partial) 206 else 200,
                if (partial) "Partial Content" else "OK",
                headers, LimitedStream(fis, len, afd)
            )
        } catch (e: Exception) {
            notFound()
        }
    }

    private fun serveArt(id: Long, albumId: Long): WebResourceResponse {
        val bmp = MediaUtil.loadArt(applicationContext, id, albumId, 600) ?: return notFound()
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 88, bos)
        return WebResourceResponse(
            "image/jpeg", null, 200, "OK", HashMap<String, String>(),
            ByteArrayInputStream(bos.toByteArray())
        )
    }

    // ---------- lifecycle ----------
    @Suppress("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(0xFF2B2B29.toInt())
        setContentView(web)
        Bridge.web = web

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.textZoom = 100
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isLongClickable = false
        web.setOnLongClickListener { true }
        web.isHapticFeedbackEnabled = false

        web.addJavascriptInterface(JsApi(), "FAudio")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val u = request.url
                if (u.host != host) return null
                val path = u.path ?: "/"
                return when {
                    path.startsWith("/song/") -> {
                        val id = path.substring(6).toLongOrNull() ?: return notFound()
                        serveSong(id, request.requestHeaders["Range"])
                    }
                    path.startsWith("/art/") -> {
                        val id = path.substring(5).toLongOrNull() ?: return notFound()
                        val al = u.getQueryParameter("al")?.toLongOrNull() ?: -1L
                        serveArt(id, al)
                    }
                    else -> serveAsset(path)
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "audio/*"
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                return try {
                    startActivityForResult(Intent.createChooser(i, "Select songs"), 77)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    filePathCallback?.onReceiveValue(null)
                    false
                }
            }
        }

        web.loadUrl("https://$host/")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            val r: Array<Uri>? =
                if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                else null
            fileCb?.onReceiveValue(r)
            fileCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBackPressed&&window.onBackPressed())") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    override fun onDestroy() {
        PlayerService.stop()
        Bridge.web = null
        try {
            web.destroy()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
