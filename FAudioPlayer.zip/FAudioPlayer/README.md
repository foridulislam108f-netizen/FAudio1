# FAudio Player
HTML UI (app/src/main/assets/index.html) + Android WebView wrapper.
- ফোনের সব গান MediaStore থেকে নিজে থেকে যোগ হয় (প্রথমবার Allow দিতে হবে)
- libVLC ইঞ্জিন: প্রায় সব অডিও ফরম্যাট চলে (WMA, APE, FLAC, Opus, DSF, AC3, DTS, MKA ...)
- Add files দিয়ে হাতে বাছা গান অ্যাপ বন্ধ করলেও সংরক্ষিত থাকে
- ব্যাকগ্রাউন্ডে প্লে + নোটিফিকেশন কন্ট্রোল (Prev / Play-Pause / Next / Close)
- GitHub Actions দিয়ে APK বিল্ড: Actions → Build FAudio Player APK → Artifacts → FAudioPlayer-apk

## Fixes in this build
- Android 11+ delete now reports failure correctly and waits for the system confirmation result.
- Android 10 and older delete operations now return the real result.
- MediaStore rename/delete flows no longer report false success.
- Renamed song titles are persisted locally and remain visible after rescans and app restarts.
- Background playback survives removing the Activity from recents.
- WebView is no longer forcibly resumed during Activity pause/stop.
- Native progress callbacks are throttled to reduce notification/WebView work and playback stutter.
- Added Gradle Wrapper 8.7 for reproducible builds.
- Fixed Add songs on newer Android by handling single and multiple document-picker URI results, including providers where WebView parseResult returns no URI.

## Playback and playlist improvements
- Audio focus now pauses for transient interruptions, ducks for short interruptions, and resumes only when appropriate.
- Disconnecting wired/Bluetooth audio sends a pause event, decoder errors get one recovery attempt, and long-song position saving remains persistent.
- Added Mono audio toggle for native playback.
- Added persistent playlists with create, rename, delete, reorder, play, add-to-playlist, Play next, Add to queue, Recently played and Most played views.

The display title now follows the current MediaStore filename instead of stale embedded TITLE metadata, so renames made in the player, a file manager, or after a downloader rescan remain visible.

The audio channel selector now has four modes: Off (original stereo), Mono (mixed left and right), Left, and Right. The selected mode is saved and restored on the next launch.

The Left and Right channel modes now use VLC's correct `sout-mono-channel` and `sout-mono-downmix` options; the previous parameter names were ineffective.

Channel filter options are now passed when creating the LibVLC engine, and changing the mode recreates that engine so the filter is applied immediately instead of remaining cached.

## Background playback reliability (this build)
- Play queue now lives in the native player: the next song starts even with the screen off, the page frozen or the Activity destroyed. Notification / headset Next, Prev, Play, Pause work natively.
- Activity.onDestroy no longer stops music that is playing (only cleans up when nothing plays).
- Foreground service: promoted first thing in onStartCommand, refusal (Android 12+ background start) is no longer swallowed: it is retried when the app returns to the foreground; sticky restart resumes playback after the system kills the process.
- Play / Resume reload the song when the engine is stopped, ended or in error; the page is told if nothing could be played.
- Error recovery: 3 retries with growing delay, resuming at the same position, then skip to the next song (max 3 in a row); counters reset after real playback. The page no longer skips on a single transient error.
- Audio focus: request result is checked (delayed / failed handled), permanent loss pauses and abandons focus, focus is abandoned on pause / stop / release.
- Page re-attaches to a running native player when the Activity is re-created.
