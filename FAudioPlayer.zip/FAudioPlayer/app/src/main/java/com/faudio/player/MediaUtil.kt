package com.faudio.player

import android.content.ContentUris
import android.content.ContentValues
import android.content.IntentSender
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import org.json.JSONArray
import org.json.JSONObject

object MediaUtil {

    private fun titleOverride(ctx: Context, id: Long): String? =
        ctx.getSharedPreferences("faudio", Context.MODE_PRIVATE)
            .getString("title_override_$id", null)

    private fun saveTitleOverride(ctx: Context, id: Long, title: String) {
        ctx.getSharedPreferences("faudio", Context.MODE_PRIVATE)
            .edit().putString("title_override_$id", title).apply()
    }

    fun songUri(id: Long): Uri =
        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    /** Album art / embedded cover of a song, or null. */
    fun loadArt(ctx: Context, id: Long, albumId: Long, px: Int): Bitmap? {
        if (id < 0) return null
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(songUri(id), Size(px, px), null)
            } else {
                val u = ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"), albumId
                )
                ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
            }
        } catch (e: Exception) {
            null
        }
    }

    /** All songs on the device as a JSON array string. */
    fun querySongs(ctx: Context, minSec: Int): String {
        val out = JSONArray()
        try {
            val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val proj = mutableListOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.MIME_TYPE,
                MediaStore.Audio.Media.DATE_ADDED
            )
            if (Build.VERSION.SDK_INT >= 29) proj.add(MediaStore.Audio.Media.RELATIVE_PATH)

            val sel = "(" + MediaStore.Audio.Media.DURATION + " >= ? OR " +
                MediaStore.Audio.Media.DURATION + " IS NULL) AND " +
                MediaStore.Audio.Media.IS_RINGTONE + " = 0 AND " +
                MediaStore.Audio.Media.IS_NOTIFICATION + " = 0 AND " +
                MediaStore.Audio.Media.IS_ALARM + " = 0"
            val args = arrayOf((minSec * 1000L).toString())

            ctx.contentResolver.query(m, proj.toTypedArray(), sel, args, null)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iT = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iA = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iB = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iAl = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iD = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iN = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val iS = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val iM = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val iDa = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val iP = if (Build.VERSION.SDK_INT >= 29)
                    c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH) else -1

                while (c.moveToNext()) {
                    val name = c.getString(iN) ?: ""
                    var title = titleOverride(ctx, c.getLong(iId)) ?: (c.getString(iT) ?: "")
                    if (title.isBlank()) title = name.substringBeforeLast('.')
                    var artist = c.getString(iA) ?: ""
                    if (artist == "<unknown>") artist = ""
                    var album = c.getString(iB) ?: ""
                    if (album == "<unknown>") album = ""

                    val o = JSONObject()
                    o.put("id", c.getLong(iId))
                    o.put("t", title)
                    o.put("a", artist)
                    o.put("b", album)
                    o.put("al", c.getLong(iAl))
                    o.put("d", c.getLong(iD))
                    o.put("n", name)
                    o.put("s", c.getLong(iS))
                    o.put("m", c.getString(iM) ?: "")
                    o.put("da", c.getLong(iDa))
                    o.put("f", if (iP >= 0) (c.getString(iP) ?: "") else "")
                    out.put(o)
                }
            }
        } catch (e: Exception) {
            // permission missing or query failed: return what we have
        }
        return out.toString()
    }

    /** Rename a MediaStore audio item (title + file name, keeping the extension). May throw SecurityException. */
    fun renameSong(ctx: Context, id: Long, newTitle: String): Boolean {
        if (id < 0 || newTitle.isBlank()) return false
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.TITLE, newTitle)
            val safe = newTitle.replace(Regex("[\\/:*?\"<>|]"), "_").trim()
            if (safe.isNotEmpty()) {
                var ext = ""
                try {
                    ctx.contentResolver.query(
                        songUri(id), arrayOf(MediaStore.Audio.Media.DISPLAY_NAME), null, null, null
                    )?.use { c ->
                        if (c.moveToFirst()) {
                            val old = c.getString(0) ?: ""
                            if (old.contains(".")) ext = "." + old.substringAfterLast('.')
                        }
                    }
                } catch (_: Exception) {
                }
                put(MediaStore.Audio.Media.DISPLAY_NAME, safe + ext)
            }
        }
        val updated = ctx.contentResolver.update(songUri(id), values, null, null) > 0
        if (updated) saveTitleOverride(ctx, id, newTitle.trim())
        return updated
    }

    /**
     * Delete one or more songs.
     * On Android 11+ this returns an IntentSender so the system can show the
     * confirmation dialog. On older versions callers should use deleteSongsDirect.
     * Returns null only when no system confirmation is required or creation failed.
     */
    fun deleteSongs(ctx: Context, ids: LongArray): IntentSender? {
        if (ids.isEmpty()) return null
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                val uris = ids.map { songUri(it) }
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, uris)
                pi.intentSender
            } else {
                null // direct deletion is handled by deleteSongsDirect
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Direct deletion for Android 10 and below. */
    fun deleteSongsDirect(ctx: Context, ids: LongArray): Boolean {
        if (ids.isEmpty()) return false
        var deleted = 0
        for (id in ids) {
            try {
                if (ctx.contentResolver.delete(songUri(id), null, null) > 0) deleted++
            } catch (_: Exception) {
                // Continue so one inaccessible item does not hide the other results.
            }
        }
        return deleted == ids.size
    }
}
