package com.faudio.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class PlayState(
    val id: Long,
    val albumId: Long,
    val title: String,
    val artist: String,
    val playing: Boolean,
    val pos: Long,
    val dur: Long
)

/**
 * Foreground service: keeps the process alive while music plays in the WebView
 * and shows the notification with Prev / Play-Pause / Next / Close.
 */
class PlayerService : Service() {

    companion object {
        const val CHANNEL = "faudio_playback"
        const val NID = 11

        @Volatile
        var instance: PlayerService? = null

        @Volatile
        var pending: PlayState? = null

        fun push(ctx: Context, st: PlayState) {
            val s = instance
            if (s != null) {
                s.update(st)
                return
            }
            if (!st.playing) return
            pending = st
            try {
                val i = Intent(ctx, PlayerService::class.java)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
                // not allowed right now: playback still works, just without notification
            }
        }

        fun stop() {
            instance?.shutdown()
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var session: MediaSession
    private var state: PlayState? = null
    private var art: Bitmap? = null
    private var artId: Long = Long.MIN_VALUE
    private var foreground = false
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Music playback", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        session = MediaSession(this, "FAudioPlayer")
        session.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { setPlaying(true) }
            override fun onPause() { setPlaying(false) }
            override fun onStop() { setPlaying(false) }
            override fun onSkipToNext() { Bridge.js("window.faudioCmd('next')") }
            override fun onSkipToPrevious() { Bridge.js("window.faudioCmd('prev')") }
            override fun onSeekTo(pos: Long) { Bridge.js("window.faudioCmd('seek'," + pos + ")") }
        })
        session.isActive = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "prev" -> Bridge.js("window.faudioCmd('prev')")
            "next" -> Bridge.js("window.faudioCmd('next')")
            "toggle" -> {
                val cur = state
                setPlaying(!(cur != null && cur.playing))
            }
            "close" -> {
                Bridge.js("window.faudioCmd('pause')")
                shutdown()
                return START_NOT_STICKY
            }
        }
        if (!foreground) {
            update(pending ?: PlayState(-1, -1, "FAudio Player", "", false, 0, 0))
        }
        return START_NOT_STICKY
    }

    /**
     * Play / pause straight on the native engine (works even when the page is
     * frozen in the background), flip the notification at once, and also tell the
     * page so its own state and the UI stay in sync.
     */
    private fun setPlaying(play: Boolean) {
        try {
            if (play) NativePlayer.resume(applicationContext) else NativePlayer.pause()
        } catch (e: Exception) {
        }
        val cur = state
        if (cur != null) {
            state = PlayState(cur.id, cur.albumId, cur.title, cur.artist, play, cur.pos, cur.dur)
            refresh()
        }
        Bridge.js(if (play) "window.faudioCmd('play')" else "window.faudioCmd('pause')")
    }

    fun update(s: PlayState) {
        state = s
        if (s.id != artId) {
            artId = s.id
            art = null
            val id = s.id
            val al = s.albumId
            Thread {
                val b = MediaUtil.loadArt(applicationContext, id, al, 512)
                main.post {
                    if (artId == id) {
                        art = b
                        refresh()
                    }
                }
            }.start()
        }
        refresh()
    }

    private fun act(icon: Int, title: String, action: String, code: Int): Notification.Action {
        val pi = PendingIntent.getService(
            this, code,
            Intent(this, PlayerService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi).build()
    }

    private fun refresh() {
        val s = state ?: return
        try {
            // lock-screen / media-button session
            val md = MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, s.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, s.artist)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, s.dur)
            art?.let { md.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) }
            session.setMetadata(md.build())

            val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or
                PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO or
                PlaybackState.ACTION_STOP
            val pb = PlaybackState.Builder()
                .setActions(actions)
                .setState(
                    if (s.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    s.pos,
                    if (s.playing) 1f else 0f
                )
                .build()
            session.setPlaybackState(pb)

            val open = PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            else Notification.Builder(this)
            b.setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(s.title)
                .setContentText(if (s.artist.isEmpty()) "FAudio Player" else s.artist)
                .setContentIntent(open)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setOngoing(s.playing)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(act(R.drawable.ic_prev, "Previous", "prev", 1))
                .addAction(
                    if (s.playing) act(R.drawable.ic_pause, "Pause", "toggle", 2)
                    else act(R.drawable.ic_play, "Play", "toggle", 2)
                )
                .addAction(act(R.drawable.ic_next, "Next", "next", 3))
                .addAction(act(R.drawable.ic_close, "Close", "close", 4))
                .setStyle(
                    Notification.MediaStyle()
                        .setMediaSession(session.sessionToken)
                        .setShowActionsInCompactView(0, 1, 2)
                )
            art?.let { b.setLargeIcon(it) }
            val n = b.build()

            if (!foreground) {
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                } else {
                    startForeground(NID, n)
                }
                foreground = true
            } else {
                (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NID, n)
            }

            if (s.playing) {
                if (wake == null) {
                    val pm = getSystemService(POWER_SERVICE) as PowerManager
                    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "faudio:play")
                    wake?.setReferenceCounted(false)
                }
                wake?.acquire(6 * 60 * 60 * 1000L)
            } else {
                releaseWake()
            }
        } catch (e: Exception) {
            // never crash the player because of the notification
        }
    }

    private fun releaseWake() {
        try {
            wake?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
        }
    }

    fun shutdown() {
        try {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
        }
        foreground = false
        releaseWake()
        instance = null
        pending = null
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        shutdown()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        releaseWake()
        try {
            session.release()
        } catch (e: Exception) {
        }
        instance = null
        super.onDestroy()
    }
}
