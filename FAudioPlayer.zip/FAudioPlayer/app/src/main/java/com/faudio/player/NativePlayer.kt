package com.faudio.player

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia

/**
 * libVLC based engine: plays practically every audio format
 * (mp3, aac, m4a, flac, ogg, opus, wav, wma, ape, wv, tta, dsf, dff, ac3, dts, mka, amr, aiff, mpc, tak, mod ...)
 * The web page talks to it through window.FPlayer and receives events through window.nEvt().
 */
object NativePlayer {
    private val main = Handler(Looper.getMainLooper())
    private var lib: LibVLC? = null
    private var player: MediaPlayer? = null
    private var fd: ParcelFileDescriptor? = null
    private var startAt = 0L
    private var rate = 1f
    private var lastPush = 0L
    private var focusReq: AudioFocusRequest? = null
    private var am: AudioManager? = null
    private var resumeOnGain = false
    private var currentCtx: Context? = null
    private var currentUri: android.net.Uri? = null
    private var currentStartMs = 0L
    private var currentRate = 1f
    private var recoveryAttempts = 0
    // 0 = stereo/off, 1 = mono mix, 2 = left channel, 3 = right channel
    private var channelMode = 0

    private fun js(code: String) = Bridge.js(code)

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeOnGain = change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT &&
                    player?.playerState == IMedia.State.Playing
                player?.pause()
                js("window.nEvt&&window.nEvt('paused')")
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> { player?.volume = 40 }
            AudioManager.AUDIOFOCUS_GAIN -> {
                player?.volume = 100
                if (resumeOnGain) {
                    resumeOnGain = false
                    player?.play()
                    js("window.nEvt&&window.nEvt('playing')")
                }
            }
        }
    }

    private fun ensure(ctx: Context): MediaPlayer {
        player?.let { return it }
        val opts = ArrayList<String>()
        opts.add("--no-video")
        opts.add("--audio-time-stretch")
        val l = LibVLC(ctx.applicationContext, opts)
        lib = l
        val p = MediaPlayer(l)
        p.setEventListener { e ->
            when (e.type) {
                MediaPlayer.Event.Playing -> {
                    if (startAt > 0) {
                        p.time = startAt
                        startAt = 0
                    }
                    js("window.nEvt&&window.nEvt('playing')")
                }
                MediaPlayer.Event.Paused -> js("window.nEvt&&window.nEvt('paused')")
                MediaPlayer.Event.LengthChanged ->
                    js("window.nEvt&&window.nEvt('len'," + e.lengthChanged + ")")
                MediaPlayer.Event.TimeChanged -> {
                    val n = System.currentTimeMillis()
                    // Avoid flooding the WebView and notification while decoding.
                    if (n - lastPush >= 1000) {
                        lastPush = n
                        js("window.nEvt&&window.nEvt('time'," + e.timeChanged + ")")
                    }
                }
                MediaPlayer.Event.EndReached -> js("window.nEvt&&window.nEvt('end')")
                MediaPlayer.Event.EncounteredError -> {
                    val c = currentCtx
                    val u = currentUri
                    if (c != null && u != null && recoveryAttempts < 1) {
                        recoveryAttempts++
                        main.postDelayed({ loadUri(c, u, currentStartMs, currentRate) }, 350)
                    } else {
                        js("window.nEvt&&window.nEvt('error')")
                    }
                }
            }
        }
        player = p
        return p
    }

    private fun focus(ctx: Context) {
        try {
            val a = am ?: (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).also { am = it }
            if (Build.VERSION.SDK_INT >= 26) {
                val r = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                    )
                    .setOnAudioFocusChangeListener(focusListener).build()
                focusReq = r
                a.requestAudioFocus(r)
            } else {
                @Suppress("DEPRECATION")
                a.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
            }
        } catch (e: Exception) {
        }
    }

    private fun closeFd() {
        try { fd?.close() } catch (e: Exception) { }
        fd = null
    }

    fun load(ctx: Context, id: Long, startMs: Long, r: Float) =
        loadUri(ctx, MediaUtil.songUri(id), startMs, r)

    fun loadUri(ctx: Context, uri: android.net.Uri?, startMs: Long, r: Float) {
        main.post {
            try {
                val retrying = currentUri == uri && recoveryAttempts > 0
                currentCtx = ctx.applicationContext
                currentUri = uri
                currentStartMs = startMs
                currentRate = if (r > 0f) r else 1f
                val p = ensure(ctx)
                p.stop()
                closeFd()
                val f = if (uri == null) null else ctx.contentResolver.openFileDescriptor(uri, "r")
                if (f == null) {
                    js("window.nEvt&&window.nEvt('error')")
                    return@post
                }
                fd = f
                val m = Media(lib!!, f.fileDescriptor)
                m.addOption(":no-video")
                if (channelMode != 0) {
                    m.addOption(":audio-filter=mono")
                    m.addOption(":mono-channel=" + if (channelMode == 1) 2 else if (channelMode == 2) 0 else 1)
                }
                p.media = m
                m.release()
                rate = currentRate
                p.rate = rate
                startAt = startMs
                p.volume = 100
                focus(ctx)
                p.play()
                if (!retrying) recoveryAttempts = 0
            } catch (e: Exception) {
                js("window.nEvt&&window.nEvt('error')")
            }
        }
    }

    fun play(ctx: Context) {
        main.post {
            try {
                focus(ctx)
                player?.play()
            } catch (e: Exception) {
            }
        }
    }

    /** Resume only when the engine is really paused on a track (never restarts a stopped one). */
    fun resume(ctx: Context) {
        main.post {
            try {
                val p = player ?: return@post
                if (p.playerState == IMedia.State.Paused) {
                    focus(ctx)
                    p.play()
                }
            } catch (e: Exception) {
            }
        }
    }

    fun pause() {
        main.post { try { player?.pause() } catch (e: Exception) { } }
    }

    fun seek(ms: Long) {
        main.post { try { player?.time = ms } catch (e: Exception) { } }
    }

    fun setRate(r: Float) {
        rate = if (r > 0f) r else 1f
        main.post { try { player?.rate = rate } catch (e: Exception) { } }
    }

    fun setChannelMode(mode: Int) {
        channelMode = mode.coerceIn(0, 3)
        main.post {
            val wasPlaying = player?.playerState == IMedia.State.Playing
            if (!wasPlaying) return@post
            val c = currentCtx ?: return@post
            val u = currentUri ?: return@post
            val at = try { player?.time ?: 0L } catch (_: Exception) { 0L }
            loadUri(c, u, at, rate)
        }
    }

    fun stop() {
        main.post {
            try { player?.stop() } catch (e: Exception) { }
            closeFd()
        }
    }

    fun release() {
        try { player?.stop() } catch (e: Exception) { }
        try { player?.release() } catch (e: Exception) { }
        try { lib?.release() } catch (e: Exception) { }
        player = null
        lib = null
        closeFd()
        currentCtx = null
        currentUri = null
        resumeOnGain = false
    }
}
