package com.faudio.player

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.widget.Toast
import org.json.JSONObject
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia

/**
 * libVLC based engine + native play queue.
 *
 * The queue (list of song ids sent by the page) lives here, so "next song",
 * notification Next/Prev, error recovery and audio focus keep working even when
 * the WebView is frozen or the Activity is gone.
 * The page talks to it through window.FPlayer and receives events through window.nEvt()/nTrack().
 */
object NativePlayer {
    private const val MAX_RETRY = 3
    private const val DEBUG = true // temporary: shows small toasts for every player event
    private const val FOCUS_FAILED = 0
    private const val FOCUS_GRANTED = 1
    private const val FOCUS_DELAYED = 2

    private val main = Handler(Looper.getMainLooper())
    private var lib: LibVLC? = null
    private var player: MediaPlayer? = null
    private var fd: ParcelFileDescriptor? = null
    private var startAt = 0L
    private var rate = 1f
    private var lastPush = 0L
    private var lastPersist = 0L
    private var focusReq: AudioFocusRequest? = null
    private var am: AudioManager? = null
    private var resumeOnGain = false
    private var currentCtx: Context? = null
    @Volatile private var currentUri: Uri? = null
    private var currentStartMs = 0L
    private var currentRate = 1f
    private var attemptFrom = 0L
    private var recoveryAttempts = 0
    private var skipErrors = 0
    private var retryToken = 0
    // 0 = stereo/off, 1 = mono mix, 2 = left channel, 3 = right channel
    private var channelMode = 0

    @Volatile private var lastTimeMs = 0L
    @Volatile private var lastLenMs = 0L
    @Volatile private var wantPlay = false     // what the user wants (play / pause)
    @Volatile private var playingNow = false   // what the engine is really doing
    @Volatile private var opening = false
    @Volatile private var ended = false
    private var pendingPause = false

    // ---- native queue ----
    @Volatile private var qIds: List<String> = emptyList()
    @Volatile private var qPos = -1
    private var qRepeat = 0
    private var curQid: String? = null
    private var curTrack: QTrack? = null
    private val trackCache = HashMap<String, QTrack?>()

    private fun js(code: String) = Bridge.js(code)

    private fun dbg(msg: String) {
        if (!DEBUG) return
        val c = currentCtx ?: return
        main.post {
            try { Toast.makeText(c, msg, Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
        }
    }

    // ------------------------------------------------------------------ audio focus
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        dbg("focus change=" + change)
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                // Another app took focus for good: pause, let go of focus, wait for the user.
                resumeOnGain = false
                wantPlay = false
                try { player?.pause() } catch (e: Exception) { }
                playingNow = false
                abandonFocus()
                js("window.nEvt&&window.nEvt('paused')")
                pushState()
                persistPos()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeOnGain = playingNow || opening || resumeOnGain
                try { player?.pause() } catch (e: Exception) { }
                js("window.nEvt&&window.nEvt('paused')")
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                setVol(40)
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                setVol(100)
                if (resumeOnGain && wantPlay) {
                    resumeOnGain = false
                    try { player?.play() } catch (e: Exception) { }
                    js("window.nEvt&&window.nEvt('playing')")
                } else {
                    resumeOnGain = false
                }
            }
        }
    }

    private fun setVol(v: Int) {
        try {
            player?.volume = v
        } catch (e: Exception) {
        }
    }

    private fun requestFocus(ctx: Context): Int {
        return try {
            val a = am ?: (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).also { am = it }
            val res = if (Build.VERSION.SDK_INT >= 26) {
                val r = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                    )
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener(focusListener, main)
                    .build()
                focusReq = r
                a.requestAudioFocus(r)
            } else {
                @Suppress("DEPRECATION")
                a.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
            }
            when (res) {
                AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> FOCUS_GRANTED
                AudioManager.AUDIOFOCUS_REQUEST_DELAYED -> FOCUS_DELAYED
                else -> FOCUS_FAILED
            }
        } catch (e: Exception) {
            FOCUS_GRANTED // a broken focus API must never block playback
        }
    }

    private fun abandonFocus() {
        try {
            val a = am ?: return
            if (Build.VERSION.SDK_INT >= 26) {
                focusReq?.let { a.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                a.abandonAudioFocus(focusListener)
            }
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ engine
    private fun ensure(ctx: Context): MediaPlayer {
        player?.let { return it }
        val opts = ArrayList<String>()
        opts.add("--no-video")
        opts.add("--audio-time-stretch")
        if (channelMode != 0) {
            opts.add("--audio-filter=mono")
            if (channelMode == 1) {
                opts.add("--sout-mono-downmix=true")
            } else {
                opts.add("--sout-mono-downmix=false")
                opts.add("--sout-mono-channel=" + if (channelMode == 2) 0 else 1)
            }
        }
        val l = LibVLC(ctx.applicationContext, opts)
        lib = l
        val p = MediaPlayer(l)
        p.setEventListener { e ->
            val type = e.type
            val a = when (type) {
                MediaPlayer.Event.TimeChanged -> e.timeChanged
                MediaPlayer.Event.LengthChanged -> e.lengthChanged
                else -> 0L
            }
            main.post { onVlcEvent(p, type, a) }
        }
        player = p
        return p
    }

    private fun onVlcEvent(p: MediaPlayer, type: Int, a: Long) {
        if (p !== player) return
        when (type) {
            MediaPlayer.Event.Playing -> {
                dbg("VLC playing (startAt=" + startAt + ")")
                opening = false
                playingNow = true
                if (startAt > 0) {
                    p.time = startAt
                    startAt = 0
                }
                if (pendingPause) {
                    pendingPause = false
                    p.pause()
                    return
                }
                js("window.nEvt&&window.nEvt('playing')")
                pushState()
                persistPos()
            }
            MediaPlayer.Event.Paused -> {
                dbg("VLC paused")
                opening = false
                playingNow = false
                js("window.nEvt&&window.nEvt('paused')")
                pushState()
                persistPos()
            }
            MediaPlayer.Event.LengthChanged -> {
                lastLenMs = a
                js("window.nEvt&&window.nEvt('len'," + a + ")")
            }
            MediaPlayer.Event.TimeChanged -> {
                lastTimeMs = a
                // A song that really plays for a moment is healthy again.
                if ((recoveryAttempts > 0 || skipErrors > 0) && a >= attemptFrom + 1500) {
                    recoveryAttempts = 0
                    skipErrors = 0
                }
                val n = SystemClock.uptimeMillis()
                if (n - lastPush >= 1000) {
                    lastPush = n
                    js("window.nEvt&&window.nEvt('time'," + a + ")")
                }
                if (n - lastPersist >= 5000) {
                    lastPersist = n
                    persistPos()
                }
            }
            MediaPlayer.Event.EndReached -> {
                dbg("VLC end at " + lastTimeMs)
                onEnded()
            }
            MediaPlayer.Event.EncounteredError -> {
                dbg("VLC ERROR at " + lastTimeMs + "ms, retry=" + recoveryAttempts)
                opening = false
                playingNow = false
                handleError(true)
            }
        }
    }

    private fun closeFd() {
        try { fd?.close() } catch (e: Exception) { }
        fd = null
    }

    /** Opens [uri] and starts it (if audio focus allows). Must run on the main thread. */
    private fun startPlayback(ctx: Context, uri: Uri?, startMs: Long, r: Float) {
        try {
            currentCtx = ctx
            dbg("load start=" + startMs + "ms")
            currentUri = uri
            currentStartMs = startMs
            currentRate = if (r > 0f) r else 1f
            ended = false
            opening = false
            pendingPause = false
            playingNow = false
            attemptFrom = startMs
            lastTimeMs = startMs
            val p = ensure(ctx)
            p.stop()
            closeFd()
            val f = if (uri == null) null else ctx.contentResolver.openFileDescriptor(uri, "r")
            if (f == null) {
                handleError(false)
                return
            }
            fd = f
            val m = Media(lib!!, f.fileDescriptor)
            m.addOption(":no-video")
            p.media = m
            m.release()
            rate = currentRate
            p.rate = rate
            startAt = startMs
            p.volume = 100
            when (requestFocus(ctx)) {
                FOCUS_GRANTED -> {
                    opening = true
                    p.play()
                }
                FOCUS_DELAYED -> {
                    // e.g. during a call: starts by itself when focus is granted
                    resumeOnGain = true
                    js("window.nEvt&&window.nEvt('paused')")
                    pushState()
                }
                else -> {
                    wantPlay = false
                    js("window.nEvt&&window.nEvt('paused')")
                    pushState()
                    persistPos()
                }
            }
        } catch (e: Exception) {
            handleError(false)
        }
    }

    /** Retry the same song (with growing delay, resuming where it stopped), then skip, then report. */
    private fun handleError(canRetry: Boolean) {
        val c = currentCtx
        val u = currentUri
        if (canRetry && c != null && u != null && recoveryAttempts < MAX_RETRY) {
            recoveryAttempts++
            val token = ++retryToken
            val resumeAt = if (lastTimeMs > 0) lastTimeMs else currentStartMs
            val delay = 350L * recoveryAttempts * recoveryAttempts
            main.postDelayed({
                if (token == retryToken && wantPlay && currentUri == u) {
                    startPlayback(c, u, resumeAt, currentRate)
                }
            }, delay)
            return
        }
        if (c != null && wantPlay && qIds.size > 1 && skipErrors < 3) {
            val n = nextIndex(qPos, false)
            if (n >= 0) {
                skipErrors++
                if (playIndex(c, n, 0L, 1)) return
            }
        }
        wantPlay = false
        playingNow = false
        opening = false
        abandonFocus()
        js("window.nEvt&&window.nEvt('error')")
        pushState()
        persistPos()
    }

    private fun nextIndex(from: Int, wrapAlways: Boolean): Int {
        val n = from + 1
        return if (n < qIds.size) n else if (wrapAlways || qRepeat == 1) 0 else -1
    }

    private fun onEnded() {
        ended = true
        playingNow = false
        opening = false
        val c = currentCtx
        if (c == null || qIds.isEmpty() || qPos < 0) {
            js("window.nEvt&&window.nEvt('end')")
            pushState()
            return
        }
        if (qRepeat == 2) {
            startPlayback(c, currentUri, 0L, currentRate)
            return
        }
        val n = nextIndex(qPos, false)
        if (n < 0 || !playIndex(c, n, 0L, 1)) {
            // queue finished
            wantPlay = false
            abandonFocus()
            js("window.nEvt&&window.nEvt('end')")
            pushState()
            persistPos()
        }
    }

    // ------------------------------------------------------------------ queue
    private fun trackAt(ctx: Context, idx: Int): QTrack? {
        val q = qIds.getOrNull(idx) ?: return null
        if (trackCache.containsKey(q)) return trackCache[q]
        val t = when {
            q.startsWith("n") -> q.substring(1).toLongOrNull()?.let { MediaUtil.songInfo(ctx, it) }
            q.startsWith("p") -> q.substring(1).toIntOrNull()?.let { MediaUtil.pickInfo(ctx, it) }
            else -> null
        }
        if (t != null) trackCache[q] = t
        return t
    }

    /** Starts queue item [i] (skipping unavailable ones in direction [dir]). */
    private fun playIndex(ctx: Context, i: Int, startMs: Long, dir: Int): Boolean {
        val size = qIds.size
        if (size == 0) return false
        var idx = ((i % size) + size) % size
        var guard = 0
        while (guard < size) {
            val t = trackAt(ctx, idx)
            if (t != null) {
                qPos = idx
                curQid = qIds[idx]
                curTrack = t
                wantPlay = true
                recoveryAttempts = 0
                js("window.nTrack&&window.nTrack(" + idx + ",'" + qIds[idx] + "')")
                startPlayback(ctx, t.uri, startMs, currentRate)
                pushState()
                persistPos()
                return true
            }
            idx = ((idx + dir) % size + size) % size
            guard++
        }
        return false
    }

    /** The page sends its play order. [ids] empty = unchanged. Returns how many items native knows. */
    fun setQueue(ctx: Context, ids: String, cur: String, repeat: Int, force: Boolean): Int {
        val app = ctx.applicationContext
        if (ids.isNotEmpty()) qIds = ids.split(',')
        val count = qIds.size
        main.post {
            currentCtx = currentCtx ?: app
            qRepeat = repeat
            if (ids.isNotEmpty()) {
                trackCache.clear()
                try {
                    app.getSharedPreferences("faudio_native", Context.MODE_PRIVATE).edit()
                        .putString("ids", ids).putInt("rep", repeat).apply()
                } catch (e: Exception) { }
            }
            val list = qIds
            val keep = if (!force && curQid != null && list.contains(curQid!!)) curQid!! else cur
            val idx = if (keep.isNotEmpty()) list.indexOf(keep) else -1
            if (idx >= 0) {
                qPos = idx
                curQid = keep
            } else if (force) {
                qPos = -1
            }
        }
        return count
    }

    /** Page loaded a song itself: remember which queue item it is. */
    private fun syncCurTrack(ctx: Context, uri: Uri?) {
        val t = if (qPos in qIds.indices) trackAt(ctx, qPos) else null
        curTrack = if (t != null && t.uri == uri) t else null
    }

    private fun pushState() {
        val c = currentCtx ?: return
        val t = curTrack ?: return
        try {
            PlayerService.push(
                c,
                PlayState(
                    t.id, t.albumId, t.title, t.artist, playingNow,
                    lastTimeMs, if (lastLenMs > 0) lastLenMs else t.dur
                )
            )
        } catch (e: Exception) {
        }
    }

    /** Called when the app comes to the foreground: lets a blocked foreground service start again. */
    fun resyncService() {
        main.post { if (playingNow) pushState() }
    }

    // ------------------------------------------------------------------ persistence (restart after the system killed us)
    private fun persistPos() {
        val c = currentCtx ?: return
        try {
            c.getSharedPreferences("faudio_native", Context.MODE_PRIVATE).edit()
                .putInt("pos", qPos).putLong("ms", lastTimeMs).putBoolean("play", wantPlay).apply()
        } catch (e: Exception) {
        }
    }

    fun restoreAfterKill(ctx: Context) {
        val app = ctx.applicationContext
        main.post {
            if (qIds.isNotEmpty() || wantPlay) return@post
            val sp = app.getSharedPreferences("faudio_native", Context.MODE_PRIVATE)
            val ids = sp.getString("ids", "") ?: ""
            if (ids.isEmpty() || !sp.getBoolean("play", false)) return@post
            currentCtx = app
            qIds = ids.split(',')
            qRepeat = sp.getInt("rep", 0)
            val pos = sp.getInt("pos", 0).coerceIn(0, qIds.size - 1)
            playIndex(app, pos, sp.getLong("ms", 0L), 1)
        }
    }

    // ------------------------------------------------------------------ API used by the page
    fun load(ctx: Context, id: Long, startMs: Long, r: Float) =
        loadUri(ctx, MediaUtil.songUri(id), startMs, r)

    fun loadUri(ctx: Context, uri: Uri?, startMs: Long, r: Float) {
        val app = ctx.applicationContext
        main.post {
            retryToken++
            recoveryAttempts = 0
            skipErrors = 0
            wantPlay = true
            syncCurTrack(app, uri)
            startPlayback(app, uri, startMs, r)
            pushState()
            persistPos()
        }
    }

    /** Play pressed in the page. */
    fun play(ctx: Context) {
        val app = ctx.applicationContext
        main.post { doPlay(app, true) }
    }

    /** Play pressed in the notification / headset: always makes sound if a song is known. */
    fun userPlay(ctx: Context) {
        val app = ctx.applicationContext
        main.post { doPlay(app, false) }
    }

    private fun doPlay(ctx: Context, fromPage: Boolean) {
        try {
            wantPlay = true
            val p = player
            if (p != null && p.playerState == IMedia.State.Paused && !ended) {
                when (requestFocus(ctx)) {
                    FOCUS_GRANTED -> p.play()
                    FOCUS_DELAYED -> resumeOnGain = true
                    else -> {
                        wantPlay = false
                        js("window.nEvt&&window.nEvt('paused')")
                    }
                }
                return
            }
            if (p != null && (playingNow || opening) && !ended) return
            // stopped / ended / error / engine released: load the song again
            val uri = currentUri ?: curTrack?.uri
            if (uri != null) {
                val from = if (ended) 0L else lastTimeMs
                retryToken++
                recoveryAttempts = 0
                skipErrors = 0
                startPlayback(ctx, uri, from, currentRate)
                return
            }
            if (qIds.isNotEmpty()) {
                if (playIndex(ctx, if (qPos >= 0) qPos else 0, 0L, 1)) return
            }
            wantPlay = false
            if (fromPage) js("window.nEvt&&window.nEvt('paused')")
            else js("window.faudioCmd&&window.faudioCmd('play')")
        } catch (e: Exception) {
            wantPlay = false
            js("window.nEvt&&window.nEvt('paused')")
        }
    }

    fun pause() {
        main.post {
            dbg("pause() called")
            wantPlay = false
            resumeOnGain = false
            try {
                if (opening) pendingPause = true
                player?.pause()
            } catch (e: Exception) { }
            abandonFocus()
            persistPos()
        }
    }

    fun toggle(ctx: Context) {
        val app = ctx.applicationContext
        main.post {
            if (playingNow || opening) {
                wantPlay = false
                resumeOnGain = false
                try {
                    if (opening) pendingPause = true
                    player?.pause()
                } catch (e: Exception) { }
                abandonFocus()
                persistPos()
            } else {
                doPlay(app, false)
            }
        }
    }

    fun next(ctx: Context) {
        val app = ctx.applicationContext
        main.post {
            if (qIds.isEmpty()) {
                js("window.faudioCmd&&window.faudioCmd('next')")
                return@post
            }
            val n = nextIndex(qPos, true)
            playIndex(app, n, 0L, 1)
        }
    }

    fun prev(ctx: Context) {
        val app = ctx.applicationContext
        main.post {
            if (qIds.isEmpty()) {
                js("window.faudioCmd&&window.faudioCmd('prev')")
                return@post
            }
            if (lastTimeMs > 3000 && !ended) {
                try { player?.time = 0L } catch (e: Exception) { }
                lastTimeMs = 0L
                return@post
            }
            playIndex(app, if (qPos - 1 < 0) qIds.size - 1 else qPos - 1, 0L, -1)
        }
    }

    fun seek(ms: Long) {
        main.post {
            dbg("seek " + ms)
            try { player?.time = ms } catch (e: Exception) { }
            lastTimeMs = ms
        }
    }

    fun setRate(r: Float) {
        rate = if (r > 0f) r else 1f
        currentRate = rate
        main.post { try { player?.rate = rate } catch (e: Exception) { } }
    }

    fun setChannelMode(mode: Int) {
        val nextMode = mode.coerceIn(0, 3)
        main.post {
            if (channelMode == nextMode) return@post
            channelMode = nextMode
            val c = currentCtx ?: return@post
            val u = currentUri ?: return@post
            val at = try { player?.time ?: lastTimeMs } catch (_: Exception) { lastTimeMs }
            val wasPlaying = playingNow || opening
            try { player?.stop() } catch (_: Exception) { }
            try { player?.release() } catch (_: Exception) { }
            try { lib?.release() } catch (_: Exception) { }
            player = null
            lib = null
            closeFd()
            startPlayback(c, u, at, rate)
            if (!wasPlaying) {
                wantPlay = false
                pendingPause = true
            }
        }
    }

    fun stop() {
        main.post {
            dbg("stop() called")
            wantPlay = false
            playingNow = false
            opening = false
            resumeOnGain = false
            retryToken++
            try { player?.stop() } catch (e: Exception) { }
            closeFd()
            abandonFocus()
        }
    }

    fun release() {
        try { player?.stop() } catch (e: Exception) { }
        try { player?.release() } catch (e: Exception) { }
        try { lib?.release() } catch (e: Exception) { }
        player = null
        lib = null
        closeFd()
        abandonFocus()
        retryToken++
        currentCtx?.let {
            try { it.getSharedPreferences("faudio_native", Context.MODE_PRIVATE).edit().putBoolean("play", false).apply() } catch (e: Exception) { }
        }
        currentCtx = null
        currentUri = null
        curTrack = null
        curQid = null
        qIds = emptyList()
        qPos = -1
        trackCache.clear()
        wantPlay = false
        playingNow = false
        opening = false
        resumeOnGain = false
    }

    fun wantsPlay(): Boolean = wantPlay
    fun isActive(): Boolean = currentUri != null

    /** Snapshot for a freshly started page (Activity re-created while music kept playing). */
    fun stateJson(): String {
        val o = JSONObject()
        val ids = qIds
        val pos = qPos
        val active = currentUri != null && ids.isNotEmpty() && pos in ids.indices
        o.put("active", active)
        if (active) {
            o.put("ids", ids.joinToString(","))
            o.put("qid", ids[pos])
            o.put("playing", playingNow || opening)
            o.put("ms", lastTimeMs)
            o.put("len", lastLenMs)
            o.put("ended", ended)
        }
        return o.toString()
    }
}
