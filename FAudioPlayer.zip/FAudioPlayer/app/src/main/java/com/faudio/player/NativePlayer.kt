package com.faudio.player

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/**
 * libVLC based engine: plays practically every audio format
 * (mp3, aac, m4a, flac, ogg, opus, wav, wma, ape, wv, tta, dsf, dff, ac3, dts, mka, amr, aiff, mpc, tak, mod ...)
 * The web page talks to it through window.FPlayer and receives events through window.nEvt().
 */
object NativePlayer {
    private val main = Handler(Looper.getMainLooper())
    private var lib: LibVLC? = null
    private var player: MediaPlayer? = null
    private var fd: ParcelFileDescriptor? = null
    private var startAt = 0L
    private var rate = 1f
    private var lastPush = 0L
    private var focusReq: AudioFocusRequest? = null
    private var am: AudioManager? = null

    private fun js(code: String) = Bridge.js(code)

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                player?.pause()
                js("window.nEvt&&window.nEvt('paused')")
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> { player?.volume = 40 }
            AudioManager.AUDIOFOCUS_GAIN -> { player?.volume = 100 }
        }
    }

    private fun ensure(ctx: Context): MediaPlayer {
        player?.let { return it }
        val opts = ArrayList<String>()
        opts.add("--no-video")
        opts.add("--audio-time-stretch")
        val l = LibVLC(ctx.applicationContext, opts)
        lib = l
        val p = MediaPlayer(l)
        p.setEventListener { e ->
            when (e.type) {
                MediaPlayer.Event.Playing -> {
                    if (startAt > 0) {
                        p.time = startAt
                        startAt = 0
                    }
                    js("window.nEvt&&window.nEvt('playing')")
                }
                MediaPlayer.Event.Paused -> js("window.nEvt&&window.nEvt('paused')")
                MediaPlayer.Event.LengthChanged ->
                    js("window.nEvt&&window.nEvt('len'," + e.lengthChanged + ")")
                MediaPlayer.Event.TimeChanged -> {
                    val n = System.currentTimeMillis()
                    if (n - lastPush >= 250) {
                        lastPush = n
                        js("window.nEvt&&window.nEvt('time'," + e.timeChanged + ")")
                    }
                }
                MediaPlayer.Event.EndReached -> js("window.nEvt&&window.nEvt('end')")
                MediaPlayer.Event.EncounteredError -> js("window.nEvt&&window.nEvt('error')")
            }
        }
        player = p
        return p
    }

    private fun focus(ctx: Context) {
        try {
            val a = am ?: (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).also { am = it }
            if (Build.VERSION.SDK_INT >= 26) {
                val r = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                    )
                    .setOnAudioFocusChangeListener(focusListener).build()
                focusReq = r
                a.requestAudioFocus(r)
            } else {
                @Suppress("DEPRECATION")
                a.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
            }
        } catch (e: Exception) {
        }
    }

    private fun closeFd() {
        try { fd?.close() } catch (e: Exception) { }
        fd = null
    }

    fun load(ctx: Context, id: Long, startMs: Long, r: Float) =
        loadUri(ctx, MediaUtil.songUri(id), startMs, r)

    fun loadUri(ctx: Context, uri: android.net.Uri?, startMs: Long, r: Float) {
        main.post {
            try {
                val p = ensure(ctx)
                p.stop()
                closeFd()
                val f = if (uri == null) null else ctx.contentResolver.openFileDescriptor(uri, "r")
                if (f == null) {
                    js("window.nEvt&&window.nEvt('error')")
                    return@post
                }
                fd = f
                val m = Media(lib!!, f.fileDescriptor)
                m.addOption(":no-video")
                p.media = m
                m.release()
                rate = if (r > 0f) r else 1f
                p.rate = rate
                startAt = startMs
                p.volume = 100
                focus(ctx)
                p.play()
            } catch (e: Exception) {
                js("window.nEvt&&window.nEvt('error')")
            }
        }
    }

    fun play(ctx: Context) {
        main.post {
            try {
                focus(ctx)
                player?.play()
            } catch (e: Exception) {
            }
        }
    }

    /** Resume only when the engine is really paused on a track (never restarts a stopped one). */
    fun resume(ctx: Context) {
        main.post {
            try {
                val p = player ?: return@post
                if (p.playerState == Media.State.Paused) {
                    focus(ctx)
                    p.play()
                }
            } catch (e: Exception) {
            }
        }
    }

    fun pause() {
        main.post { try { player?.pause() } catch (e: Exception) { } }
    }

    fun seek(ms: Long) {
        main.post { try { player?.time = ms } catch (e: Exception) { } }
    }

    fun setRate(r: Float) {
        rate = if (r > 0f) r else 1f
        main.post { try { player?.rate = rate } catch (e: Exception) { } }
    }

    fun stop() {
        main.post {
            try { player?.stop() } catch (e: Exception) { }
            closeFd()
        }
    }

    fun release() {
        try { player?.stop() } catch (e: Exception) { }
        try { player?.release() } catch (e: Exception) { }
        try { lib?.release() } catch (e: Exception) { }
        player = null
        lib = null
        closeFd()
    }
}
