package com.faudio.player

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.InputStream

/** Lets the service talk to the page. */
object Bridge {
    @Volatile
    var web: WebView? = null

    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    fun js(code: String) {
        ui.post {
            val w = web
            if (w != null) {
                try {
                    w.evaluateJavascript(code, null)
                } catch (e: Exception) {
                }
            }
        }
    }
}

class MainActivity : Activity() {

    private val host = "appassets.androidplatform.net"
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pickMode = false
    private var pendingRenameId = -1L
    private var pendingRenameTitle = ""
    private val picked = ArrayList<Uri>()
    private val pickedArt = HashMap<Int, ByteArray?>()
    private var pickedMeta = org.json.JSONArray()

    private fun prefs() = getSharedPreferences("faudio", MODE_PRIVATE)

    private fun loadPickedFromPrefs() {
        try {
            val arr = org.json.JSONArray(prefs().getString("picked", "[]"))
            for (k in 0 until arr.length()) {
                val o = arr.getJSONObject(k)
                picked.add(Uri.parse(o.getString("u")))
                pickedMeta.put(o)
            }
        } catch (e: Exception) {
            picked.clear()
            pickedMeta = org.json.JSONArray()
        }
    }

    private fun savePicked() {
        try { prefs().edit().putString("picked", pickedMeta.toString()).apply() } catch (e: Exception) { }
    }

    private fun artFor(i: Int): ByteArray? {
        val u = picked.getOrNull(i) ?: return null
        return try {
            val r = android.media.MediaMetadataRetriever()
            r.setDataSource(applicationContext, u)
            val pic = r.embeddedPicture
            r.release()
            pickedArt[i] = pic
            pic
        } catch (e: Exception) {
            null
        }
    }

    // ---------- permissions ----------
    private fun audioPerm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission(): Boolean =
        checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED

    private fun askPermission() {
        val list = ArrayList<String>()
        list.add(audioPerm())
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Bridge.js("window.onPermission&&window.onPermission(" + hasAudioPermission() + ")")
    }

    // ---------- JS bridge ----------
    inner class JsApi {
        @JavascriptInterface
        fun hasPermission(): Boolean = hasAudioPermission()

        @JavascriptInterface
        fun requestPermission() {
            runOnUiThread { askPermission() }
        }

        @JavascriptInterface
        fun getSongs(minSec: Int): String = MediaUtil.querySongs(applicationContext, minSec)

        @JavascriptInterface
        fun nowPlaying(
            id: Long, albumId: Long, title: String, artist: String,
            playing: Boolean, posMs: Long, durMs: Long
        ) {
            val st = PlayState(id, albumId, title, artist, playing, posMs, durMs)
            runOnUiThread { PlayerService.push(applicationContext, st) }
        }

        @JavascriptInterface
        fun share(id: Long) {
            runOnUiThread {
                try {
                    val uri = MediaUtil.songUri(id)
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "audio/*"
                    i.putExtra(Intent.EXTRA_STREAM, uri)
                    i.clipData = ClipData.newRawUri("", uri)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, null))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun getPicked(): String {
            val out = org.json.JSONArray()
            synchronized(picked) {
                for (k in 0 until pickedMeta.length()) {
                    val o = org.json.JSONObject(pickedMeta.getJSONObject(k).toString())
                    o.remove("u")
                    out.put(o)
                }
            }
            return out.toString()
        }

        @JavascriptInterface
        fun clearPicked() {
            synchronized(picked) {
                for (u in picked) {
                    try { contentResolver.releasePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
                }
                picked.clear()
                pickedArt.clear()
                pickedMeta = org.json.JSONArray()
            }
            savePicked()
        }

        @JavascriptInterface
        fun sharePick(i: Int) {
            runOnUiThread {
                try {
                    val uri = picked.getOrNull(i) ?: return@runOnUiThread
                    val it = Intent(Intent.ACTION_SEND)
                    it.type = "audio/*"
                    it.putExtra(Intent.EXTRA_STREAM, uri)
                    it.clipData = ClipData.newRawUri("", uri)
                    it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(it, null))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun setBars(light: Boolean) {
            runOnUiThread { applyBars(light) }
        }

        /** Rename a song by MediaStore id. Returns "ok", "pending" (system permission dialog) or "fail". */
        @JavascriptInterface
        fun renameSong(id: Long, newTitle: String): String {
            val t = newTitle.trim()
            return try {
                if (MediaUtil.renameSong(applicationContext, id, t)) "ok" else "fail"
            } catch (e: SecurityException) {
                try {
                    val sender: IntentSender? =
                        if (Build.VERSION.SDK_INT >= 30) {
                            android.provider.MediaStore.createWriteRequest(
                                contentResolver, listOf(MediaUtil.songUri(id))
                            ).intentSender
                        } else if (Build.VERSION.SDK_INT == 29 && e is android.app.RecoverableSecurityException) {
                            e.userAction.actionIntent.intentSender
                        } else null
                    if (sender == null) "fail"
                    else {
                        pendingRenameId = id
                        pendingRenameTitle = t
                        runOnUiThread {
                            try {
                                startIntentSenderForResult(sender, 89, null, 0, 0, 0)
                            } catch (ex: Exception) {
                                Bridge.js("window.onRenameResult&&window.onRenameResult(false)")
                            }
                        }
                        "pending"
                    }
                } catch (ex: Exception) {
                    "fail"
                }
            } catch (e: Exception) {
                "fail"
            }
        }

        /**
         * Request deletion of one or more songs.
         * On Android 11+ the system confirmation dialog is shown.
         * Returns "ok" (deleted immediately / request launched) or "fail".
         */
        @JavascriptInterface
        fun deleteSongs(idsJson: String): String {
            return try {
                val arr = org.json.JSONArray(idsJson)
                val ids = LongArray(arr.length()) { arr.getLong(it) }
                if (ids.isEmpty()) return "fail"
                if (Build.VERSION.SDK_INT < 30) {
                    val ok = MediaUtil.deleteSongsDirect(applicationContext, ids)
                    Bridge.js("window.onDeleteResult&&window.onDeleteResult(" + ok + ")")
                    return if (ok) "ok" else "fail"
                }
                val sender = MediaUtil.deleteSongs(applicationContext, ids)
                if (sender != null) {
                    // Android 11+: show system confirmation
                    runOnUiThread {
                        try {
                            startIntentSenderForResult(sender, 88, null, 0, 0, 0)
                        } catch (e: Exception) {
                            Bridge.js("window.onDeleteResult&&window.onDeleteResult(false)")
                        }
                    }
                    "pending"
                } else {
                    // Request creation failed; never report a false success to the page.
                    "fail"
                }
            } catch (e: Exception) {
                "fail"
            }
        }
    }

    /** Native audio engine (libVLC) used for every song of the phone. */
    inner class PlayerApi {
        @JavascriptInterface
        fun load(id: Long, startMs: Long, rate: Float) =
            NativePlayer.load(applicationContext, id, startMs, rate)

        @JavascriptInterface
        fun loadPick(i: Int, startMs: Long, rate: Float) =
            NativePlayer.loadUri(applicationContext, picked.getOrNull(i), startMs, rate)

        @JavascriptInterface
        fun play() = NativePlayer.play(applicationContext)

        @JavascriptInterface
        fun pause() = NativePlayer.pause()

        @JavascriptInterface
        fun seek(ms: Long) = NativePlayer.seek(ms)

        @JavascriptInterface
        fun rate(r: Float) = NativePlayer.setRate(r)

        @JavascriptInterface
        fun stop() = NativePlayer.stop()
    }

    @Suppress("DEPRECATION")
    private fun applyBars(light: Boolean) {
        window.statusBarColor = if (light) 0xFFFBFBF7.toInt() else 0xFF8C8C88.toInt()
        window.navigationBarColor = if (light) 0xFFC6C6BE.toInt() else 0xFF2B2B29.toInt()
        var flags = 0
        if (light) {
            if (Build.VERSION.SDK_INT >= 23) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
    }

    // ---------- serving assets / songs / covers to the WebView ----------
    private fun notFound(): WebResourceResponse =
        WebResourceResponse(
            "text/plain", "utf-8", 404, "Not Found", HashMap<String, String>(),
            ByteArrayInputStream(ByteArray(0))
        )

    private fun mimeFor(name: String): String {
        val n = name.lowercase()
        return when {
            n.endsWith(".html") -> "text/html"
            n.endsWith(".js") -> "application/javascript"
            n.endsWith(".css") -> "text/css"
            n.endsWith(".json") -> "application/json"
            n.endsWith(".png") -> "image/png"
            n.endsWith(".jpg") || n.endsWith(".jpeg") -> "image/jpeg"
            n.endsWith(".webp") -> "image/webp"
            n.endsWith(".svg") -> "image/svg+xml"
            else -> "application/octet-stream"
        }
    }

    private fun serveAsset(path: String): WebResourceResponse? {
        val name = if (path == "/" || path.isEmpty()) "index.html" else path.trimStart('/')
        return try {
            val mime = mimeFor(name)
            WebResourceResponse(
                mime, if (mime.startsWith("text/") || mime.contains("javascript")) "utf-8" else null,
                assets.open(name)
            )
        } catch (e: Exception) {
            notFound()
        }
    }

    private class LimitedStream(
        private val fis: FileInputStream,
        private var left: Long,
        private val afd: android.content.res.AssetFileDescriptor
    ) : InputStream() {
        override fun read(): Int {
            if (left <= 0) return -1
            val r = fis.read()
            if (r >= 0) left--
            return r
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val want = if (len.toLong() > left) left.toInt() else len
            val r = fis.read(b, off, want)
            if (r > 0) left -= r.toLong()
            return r
        }

        override fun available(): Int = if (left > Int.MAX_VALUE) Int.MAX_VALUE else left.toInt()

        override fun close() {
            try { fis.close() } catch (e: Exception) { }
            try { afd.close() } catch (e: Exception) { }
        }
    }

    /** Song bytes with HTTP Range support so seeking works. */
    private fun serveSong(id: Long, range: String?): WebResourceResponse? {
        return try {
            val uri = MediaUtil.songUri(id)
            val afd = contentResolver.openAssetFileDescriptor(uri, "r") ?: return notFound()
            var total = afd.length
            if (total < 0) total = afd.parcelFileDescriptor.statSize
            if (total <= 0) {
                afd.close()
                return notFound()
            }
            var start = 0L
            var end = total - 1
            var partial = false
            if (range != null && range.startsWith("bytes=")) {
                val p = range.substring(6).split(",")[0].trim().split("-")
                val s = if (p.isNotEmpty()) p[0] else ""
                val e = if (p.size > 1) p[1] else ""
                if (s.isNotEmpty()) {
                    start = s.toLong()
                    if (e.isNotEmpty()) end = minOf(e.toLong(), total - 1)
                } else if (e.isNotEmpty()) {
                    start = maxOf(0L, total - e.toLong())
                }
                partial = true
            }
            if (start > end || start >= total) {
                afd.close()
                return WebResourceResponse(
                    "text/plain", "utf-8", 416, "Range Not Satisfiable",
                    hashMapOf("Content-Range" to "bytes */$total"),
                    ByteArrayInputStream(ByteArray(0))
                )
            }
            val fis = FileInputStream(afd.fileDescriptor)
            fis.channel.position(afd.startOffset + start)
            val len = end - start + 1
            val headers = HashMap<String, String>()
            headers["Accept-Ranges"] = "bytes"
            headers["Content-Length"] = len.toString()
            headers["Access-Control-Allow-Origin"] = "*"
            if (partial) headers["Content-Range"] = "bytes $start-$end/$total"
            val mime = contentResolver.getType(uri) ?: "audio/mpeg"
            WebResourceResponse(
                mime, null,
                if (partial) 206 else 200,
                if (partial) "Partial Content" else "OK",
                headers, LimitedStream(fis, len, afd)
            )
        } catch (e: Exception) {
            notFound()
        }
    }

    private fun serveArt(id: Long, albumId: Long): WebResourceResponse {
        val bmp = MediaUtil.loadArt(applicationContext, id, albumId, 600) ?: return notFound()
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 88, bos)
        return WebResourceResponse(
            "image/jpeg", null, 200, "OK", HashMap<String, String>(),
            ByteArrayInputStream(bos.toByteArray())
        )
    }

    // ---------- lifecycle ----------
    @Suppress("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadPickedFromPrefs()
        web = WebView(this)
        web.setBackgroundColor(0xFF2B2B29.toInt())
        setContentView(web)
        Bridge.web = web

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.textZoom = 100
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isLongClickable = false
        web.setOnLongClickListener { true }
        web.isHapticFeedbackEnabled = false

        web.addJavascriptInterface(JsApi(), "FAudio")
        web.addJavascriptInterface(PlayerApi(), "FPlayer")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val scheme = u.scheme ?: return false
                if (scheme == "mailto") {
                    openMail(u)
                    return true
                }
                if (scheme == "http" || scheme == "https") {
                    if (u.host == host) return false
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                    }
                    return true
                }
                return false
            }

            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val u = request.url
                if (u.host != host) return null
                val path = u.path ?: "/"
                return when {
                    path.startsWith("/song/") -> {
                        val id = path.substring(6).toLongOrNull() ?: return notFound()
                        serveSong(id, request.requestHeaders["Range"])
                    }
                    path.startsWith("/pickart/") -> {
                        val i = path.substring(9).toIntOrNull() ?: return notFound()
                        val b = pickedArt[i] ?: artFor(i) ?: return notFound()
                        WebResourceResponse(
                            "image/jpeg", null, 200, "OK", HashMap<String, String>(),
                            ByteArrayInputStream(b)
                        )
                    }
                    path.startsWith("/art/") -> {
                        val id = path.substring(5).toLongOrNull() ?: return notFound()
                        val al = u.getQueryParameter("al")?.toLongOrNull() ?: -1L
                        serveArt(id, al)
                    }
                    else -> serveAsset(path)
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onJsPrompt(
                view: WebView?, url: String?, message: String?, defaultValue: String?,
                result: android.webkit.JsPromptResult?
            ): Boolean {
                val input = android.widget.EditText(this@MainActivity)
                input.setText(defaultValue ?: "")
                input.setSelectAllOnFocus(true)
                input.setSingleLine(true)
                val pad = (20 * resources.displayMetrics.density).toInt()
                val box = android.widget.FrameLayout(this@MainActivity)
                box.setPadding(pad, pad / 2, pad, 0)
                box.addView(input)
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle(message ?: "")
                    .setView(box)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm(input.text.toString()) }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(
                view: WebView?, url: String?, message: String?, result: android.webkit.JsResult?
            ): Boolean {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setMessage(message ?: "")
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsAlert(
                view: WebView?, url: String?, message: String?, result: android.webkit.JsResult?
            ): Boolean {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setMessage(message ?: "")
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                val wantsAudio = fileChooserParams?.acceptTypes?.any { it.startsWith("audio") } == true
                pickMode = wantsAudio
                val i = Intent(if (wantsAudio) Intent.ACTION_OPEN_DOCUMENT else Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = if (wantsAudio) "*/*" else "audio/*"
                if (wantsAudio) i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "application/ogg", "application/octet-stream"))
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                if (wantsAudio) i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                return try {
                    startActivityForResult(if (wantsAudio) i else Intent.createChooser(i, "Select songs"), 77)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    filePathCallback?.onReceiveValue(null)
                    false
                }
            }
        }

        web.loadUrl("https://$host/")
    }

    /** Opens the mail app (Gmail first) with the given mailto: address. */
    private fun openMail(u: Uri) {
        val i = Intent(Intent.ACTION_SENDTO, u)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            i.setPackage("com.google.android.gm")
            startActivity(i)
        } catch (e: Exception) {
            try {
                i.setPackage(null)
                startActivity(i)
            } catch (e2: Exception) {
                try {
                    val c = Intent.createChooser(Intent(Intent.ACTION_SENDTO, u), "Email")
                    c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(c)
                } catch (e3: Exception) {
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            val r: Array<Uri>? =
                if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                else null
            if (pickMode) {
                // songs picked by hand are played by the native engine (all formats)
                fileCb?.onReceiveValue(null)
                fileCb = null
                pickMode = false
                if (r != null && r.isNotEmpty()) addPicked(r)
            } else {
                fileCb?.onReceiveValue(r)
                fileCb = null
            }
        } else if (requestCode == 89) {
            // MediaStore write permission result for rename
            var ok = false
            if (resultCode == RESULT_OK && pendingRenameId >= 0) {
                ok = try {
                    MediaUtil.renameSong(applicationContext, pendingRenameId, pendingRenameTitle)
                } catch (e: Exception) {
                    false
                }
            }
            pendingRenameId = -1L
            Bridge.js("window.onRenameResult&&window.onRenameResult(" + ok + ")")
        } else if (requestCode == 88) {
            // MediaStore delete confirmation result
            val ok = resultCode == RESULT_OK
            Bridge.js("window.onDeleteResult&&window.onDeleteResult(" + ok + ")")
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun addPicked(list: Array<Uri>) {
        val app = applicationContext
        Thread {
            val arr = org.json.JSONArray()
            for (u in list) {
                try {
                    try {
                        contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (e: Exception) {
                    }
                    val old = synchronized(picked) { picked.indexOf(u) }
                    if (old >= 0) {
                        val m = org.json.JSONObject(pickedMeta.getJSONObject(old).toString())
                        m.remove("u")
                        arr.put(m)
                        continue
                    }
                    var name = ""
                    var size = 0L
                    app.contentResolver.query(u, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val n = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                            val s = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                            if (n >= 0) name = c.getString(n) ?: ""
                            if (s >= 0) size = c.getLong(s)
                        }
                    }
                    if (name.isEmpty()) name = u.lastPathSegment ?: "audio"
                    var title = ""
                    var artist = ""
                    var album = ""
                    var dur = 0L
                    var pic: ByteArray? = null
                    try {
                        val r = android.media.MediaMetadataRetriever()
                        r.setDataSource(app, u)
                        title = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE) ?: ""
                        artist = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
                        album = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: ""
                        dur = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                        pic = r.embeddedPicture
                        r.release()
                    } catch (e: Exception) {
                    }
                    val idx = synchronized(picked) {
                        picked.add(u)
                        picked.size - 1
                    }
                    if (pic != null) pickedArt[idx] = pic
                    val o = org.json.JSONObject()
                    o.put("i", idx)
                    o.put("n", name)
                    o.put("s", size)
                    o.put("t", title)
                    o.put("a", artist)
                    o.put("b", album)
                    o.put("d", dur)
                    o.put("c", pic != null)
                    val saved = org.json.JSONObject(o.toString())
                    saved.put("u", u.toString())
                    pickedMeta.put(saved)
                    arr.put(o)
                } catch (e: Exception) {
                }
            }
            savePicked()
            Bridge.js("window.onPicked&&window.onPicked(" + arr.toString() + ")")
        }.start()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBackPressed&&window.onBackPressed())") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    override fun onDestroy() {
        PlayerService.stop()
        NativePlayer.release()
        Bridge.web = null
        try {
            web.destroy()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
