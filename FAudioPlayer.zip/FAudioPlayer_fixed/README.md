# FAudio Player

HTML UI (app/src/main/assets/index.html) + Android WebView wrapper.
- ফোনের সব গান MediaStore থেকে নিজে থেকে যোগ হয় (প্রথমবার Allow দিতে হবে)
- libVLC ইঞ্জিন: প্রায় সব অডিও ফরম্যাট চলে (WMA, APE, FLAC, Opus, DSF, AC3, DTS, MKA ...)
- Add files দিয়ে হাতে বাছা গান অ্যাপ বন্ধ করলেও সংরক্ষিত থাকে
- ব্যাকগ্রাউন্ডে প্লে + নোটিফিকেশন কন্ট্রোল (Prev / Play-Pause / Next / Close)
- GitHub Actions দিয়ে APK বিল্ড: Actions → Build FAudio Player APK → Artifacts → FAudioPlayer-apk

## Fixes in this build
- Android 11+ delete now reports failure correctly and waits for the system confirmation result.
- Android 10 and older delete operations now return the real result.
- MediaStore rename/delete flows no longer report false success.
- Background playback survives removing the Activity from recents.
- WebView is no longer forcibly resumed during Activity pause/stop.
- Native progress callbacks are throttled to reduce notification/WebView work and playback stutter.
- Added Gradle Wrapper 8.7 for reproducible builds.
